﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lstImporti = New ListBox()
        Label4 = New Label()
        Label5 = New Label()
        lstDescrizione = New ListBox()
        TxtTotEntrate = New TextBox()
        Label1 = New Label()
        TxtTotUscite = New TextBox()
        Label6 = New Label()
        RbEntrata = New RadioButton()
        RbUscita = New RadioButton()
        GroupBox1 = New GroupBox()
        MenuStrip1 = New MenuStrip()
        GestioneBudgetPersonaleToolStripMenuItem = New ToolStripMenuItem()
        AggiungiMovimentoToolStripMenuItem = New ToolStripMenuItem()
        FiltraToolStripMenuItem = New ToolStripMenuItem()
        SpesaPiùAltaToolStripMenuItem = New ToolStripMenuItem()
        SpesaPiùBassaToolStripMenuItem = New ToolStripMenuItem()
        PopolaToolStripMenuItem = New ToolStripMenuItem()
        EsciToolStripMenuItem = New ToolStripMenuItem()
        CrescenteToolStripMenuItem = New ToolStripMenuItem()
        DecrescenteToolStripMenuItem = New ToolStripMenuItem()
        EsciToolStripMenuItem1 = New ToolStripMenuItem()
        PulisciToolStripMenuItem = New ToolStripMenuItem()
        EsciToolStripMenuItem2 = New ToolStripMenuItem()
        Label2 = New Label()
        TxtSpesaBassa = New TextBox()
        Label3 = New Label()
        TxtSpesaAlta = New TextBox()
        GroupBox1.SuspendLayout()
        MenuStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' lstImporti
        ' 
        lstImporti.FormattingEnabled = True
        lstImporti.Location = New Point(533, 71)
        lstImporti.Name = "lstImporti"
        lstImporti.Size = New Size(150, 204)
        lstImporti.TabIndex = 6
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(533, 48)
        Label4.Name = "Label4"
        Label4.Size = New Size(58, 20)
        Label4.TabIndex = 7
        Label4.Text = "Importi"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(377, 48)
        Label5.Name = "Label5"
        Label5.Size = New Size(86, 20)
        Label5.TabIndex = 9
        Label5.Text = "Descrizione"
        ' 
        ' lstDescrizione
        ' 
        lstDescrizione.FormattingEnabled = True
        lstDescrizione.Location = New Point(377, 71)
        lstDescrizione.Name = "lstDescrizione"
        lstDescrizione.Size = New Size(150, 204)
        lstDescrizione.TabIndex = 8
        ' 
        ' TxtTotEntrate
        ' 
        TxtTotEntrate.Location = New Point(558, 312)
        TxtTotEntrate.Name = "TxtTotEntrate"
        TxtTotEntrate.ReadOnly = True
        TxtTotEntrate.Size = New Size(125, 27)
        TxtTotEntrate.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(451, 315)
        Label1.Name = "Label1"
        Label1.Size = New Size(101, 20)
        Label1.TabIndex = 1
        Label1.Text = "Totale Entrate"
        ' 
        ' TxtTotUscite
        ' 
        TxtTotUscite.Location = New Point(558, 356)
        TxtTotUscite.Name = "TxtTotUscite"
        TxtTotUscite.ReadOnly = True
        TxtTotUscite.Size = New Size(125, 27)
        TxtTotUscite.TabIndex = 2
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(451, 363)
        Label6.Name = "Label6"
        Label6.Size = New Size(94, 20)
        Label6.TabIndex = 10
        Label6.Text = "Totale Uscite"
        ' 
        ' RbEntrata
        ' 
        RbEntrata.AutoSize = True
        RbEntrata.Location = New Point(27, 34)
        RbEntrata.Name = "RbEntrata"
        RbEntrata.Size = New Size(77, 24)
        RbEntrata.TabIndex = 11
        RbEntrata.TabStop = True
        RbEntrata.Text = "Entrata"
        RbEntrata.UseVisualStyleBackColor = True
        ' 
        ' RbUscita
        ' 
        RbUscita.AutoSize = True
        RbUscita.Location = New Point(27, 64)
        RbUscita.Name = "RbUscita"
        RbUscita.Size = New Size(70, 24)
        RbUscita.TabIndex = 12
        RbUscita.TabStop = True
        RbUscita.Text = "Uscita"
        RbUscita.UseVisualStyleBackColor = True
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(RbUscita)
        GroupBox1.Controls.Add(RbEntrata)
        GroupBox1.Location = New Point(61, 71)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(250, 125)
        GroupBox1.TabIndex = 13
        GroupBox1.TabStop = False
        GroupBox1.Text = "Tipo"
        ' 
        ' MenuStrip1
        ' 
        MenuStrip1.BackColor = SystemColors.Control
        MenuStrip1.ImageScalingSize = New Size(20, 20)
        MenuStrip1.Items.AddRange(New ToolStripItem() {GestioneBudgetPersonaleToolStripMenuItem})
        MenuStrip1.Location = New Point(0, 0)
        MenuStrip1.Name = "MenuStrip1"
        MenuStrip1.Size = New Size(800, 40)
        MenuStrip1.TabIndex = 14
        MenuStrip1.Text = "MenuStrip1"
        ' 
        ' GestioneBudgetPersonaleToolStripMenuItem
        ' 
        GestioneBudgetPersonaleToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {AggiungiMovimentoToolStripMenuItem, FiltraToolStripMenuItem, SpesaPiùAltaToolStripMenuItem, SpesaPiùBassaToolStripMenuItem, PopolaToolStripMenuItem, EsciToolStripMenuItem, EsciToolStripMenuItem1, PulisciToolStripMenuItem, EsciToolStripMenuItem2})
        GestioneBudgetPersonaleToolStripMenuItem.Font = New Font("Georgia", 16.2F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        GestioneBudgetPersonaleToolStripMenuItem.Name = "GestioneBudgetPersonaleToolStripMenuItem"
        GestioneBudgetPersonaleToolStripMenuItem.Size = New Size(421, 36)
        GestioneBudgetPersonaleToolStripMenuItem.Text = "Gestione Budget Personale"
        GestioneBudgetPersonaleToolStripMenuItem.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' AggiungiMovimentoToolStripMenuItem
        ' 
        AggiungiMovimentoToolStripMenuItem.Font = New Font("Arial Narrow", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        AggiungiMovimentoToolStripMenuItem.Name = "AggiungiMovimentoToolStripMenuItem"
        AggiungiMovimentoToolStripMenuItem.Size = New Size(225, 26)
        AggiungiMovimentoToolStripMenuItem.Text = "Aggiungi movimento"
        ' 
        ' FiltraToolStripMenuItem
        ' 
        FiltraToolStripMenuItem.Font = New Font("Arial", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        FiltraToolStripMenuItem.Name = "FiltraToolStripMenuItem"
        FiltraToolStripMenuItem.Size = New Size(225, 26)
        FiltraToolStripMenuItem.Text = "Filtra"
        ' 
        ' SpesaPiùAltaToolStripMenuItem
        ' 
        SpesaPiùAltaToolStripMenuItem.Font = New Font("Arial", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        SpesaPiùAltaToolStripMenuItem.Name = "SpesaPiùAltaToolStripMenuItem"
        SpesaPiùAltaToolStripMenuItem.Size = New Size(225, 26)
        SpesaPiùAltaToolStripMenuItem.Text = "Spesa più alta"
        ' 
        ' SpesaPiùBassaToolStripMenuItem
        ' 
        SpesaPiùBassaToolStripMenuItem.Font = New Font("Arial", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        SpesaPiùBassaToolStripMenuItem.Name = "SpesaPiùBassaToolStripMenuItem"
        SpesaPiùBassaToolStripMenuItem.Size = New Size(225, 26)
        SpesaPiùBassaToolStripMenuItem.Text = "Spesa più bassa"
        ' 
        ' PopolaToolStripMenuItem
        ' 
        PopolaToolStripMenuItem.Font = New Font("Arial", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        PopolaToolStripMenuItem.Name = "PopolaToolStripMenuItem"
        PopolaToolStripMenuItem.Size = New Size(225, 26)
        PopolaToolStripMenuItem.Text = "Popola"
        ' 
        ' EsciToolStripMenuItem
        ' 
        EsciToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {CrescenteToolStripMenuItem, DecrescenteToolStripMenuItem})
        EsciToolStripMenuItem.Font = New Font("Arial", 9.0F, FontStyle.Bold)
        EsciToolStripMenuItem.Name = "EsciToolStripMenuItem"
        EsciToolStripMenuItem.Size = New Size(225, 26)
        EsciToolStripMenuItem.Text = "Ordina"
        ' 
        ' CrescenteToolStripMenuItem
        ' 
        CrescenteToolStripMenuItem.Name = "CrescenteToolStripMenuItem"
        CrescenteToolStripMenuItem.Size = New Size(181, 26)
        CrescenteToolStripMenuItem.Text = "Crescente"
        ' 
        ' DecrescenteToolStripMenuItem
        ' 
        DecrescenteToolStripMenuItem.Name = "DecrescenteToolStripMenuItem"
        DecrescenteToolStripMenuItem.Size = New Size(181, 26)
        DecrescenteToolStripMenuItem.Text = "Decrescente"
        ' 
        ' EsciToolStripMenuItem1
        ' 
        EsciToolStripMenuItem1.Font = New Font("Arial", 9.0F, FontStyle.Bold)
        EsciToolStripMenuItem1.Name = "EsciToolStripMenuItem1"
        EsciToolStripMenuItem1.Size = New Size(225, 26)
        EsciToolStripMenuItem1.Text = "Correggi"
        ' 
        ' PulisciToolStripMenuItem
        ' 
        PulisciToolStripMenuItem.Font = New Font("Arial", 9.0F, FontStyle.Bold)
        PulisciToolStripMenuItem.Name = "PulisciToolStripMenuItem"
        PulisciToolStripMenuItem.Size = New Size(225, 26)
        PulisciToolStripMenuItem.Text = "Pulisci"
        ' 
        ' EsciToolStripMenuItem2
        ' 
        EsciToolStripMenuItem2.Font = New Font("Arial", 9.0F, FontStyle.Bold)
        EsciToolStripMenuItem2.Name = "EsciToolStripMenuItem2"
        EsciToolStripMenuItem2.Size = New Size(225, 26)
        EsciToolStripMenuItem2.Text = "Esci"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(66, 359)
        Label2.Name = "Label2"
        Label2.Size = New Size(114, 20)
        Label2.TabIndex = 18
        Label2.Text = "Spesa più bassa"
        ' 
        ' TxtSpesaBassa
        ' 
        TxtSpesaBassa.Location = New Point(186, 356)
        TxtSpesaBassa.Name = "TxtSpesaBassa"
        TxtSpesaBassa.ReadOnly = True
        TxtSpesaBassa.Size = New Size(125, 27)
        TxtSpesaBassa.TabIndex = 17
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(78, 319)
        Label3.Name = "Label3"
        Label3.Size = New Size(102, 20)
        Label3.TabIndex = 16
        Label3.Text = "Spesa più alta"
        ' 
        ' TxtSpesaAlta
        ' 
        TxtSpesaAlta.AcceptsReturn = True
        TxtSpesaAlta.Location = New Point(186, 315)
        TxtSpesaAlta.Name = "TxtSpesaAlta"
        TxtSpesaAlta.ReadOnly = True
        TxtSpesaAlta.Size = New Size(125, 27)
        TxtSpesaAlta.TabIndex = 15
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Label2)
        Controls.Add(TxtSpesaBassa)
        Controls.Add(Label3)
        Controls.Add(TxtSpesaAlta)
        Controls.Add(GroupBox1)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(lstDescrizione)
        Controls.Add(Label4)
        Controls.Add(lstImporti)
        Controls.Add(TxtTotUscite)
        Controls.Add(Label1)
        Controls.Add(TxtTotEntrate)
        Controls.Add(MenuStrip1)
        MainMenuStrip = MenuStrip1
        Name = "Form1"
        Text = "Form1"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        MenuStrip1.ResumeLayout(False)
        MenuStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents lstImporti As ListBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lstDescrizione As ListBox
    Friend WithEvents TxtTotEntrate As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtTotUscite As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents RbEntrata As RadioButton
    Friend WithEvents RbUscita As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtSpesaBassa As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TxtSpesaAlta As TextBox
    Friend WithEvents GestioneBudgetPersonaleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AggiungiMovimentoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FiltraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SpesaPiùAltaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SpesaPiùBassaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PopolaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EsciToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EsciToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents PulisciToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EsciToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents CrescenteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DecrescenteToolStripMenuItem As ToolStripMenuItem

End Class
